<?php
        include 'header.php';
        ?>
		
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Brand
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Brand</li>
      </ol>
    </section>
  
  
   <?php
require_once 'dbconfig.php';

        if(isset($_POST['save']))
	{
		$save=$_POST['save'];
				
		if($save=='Submit')
		{
                $txtBrand = $_POST['txtBrand'];// user name
		$date = date('Y-m-d H:i:s');
                $DID=$_SESSION['UID'];
                if(!isset($errMSG))
		{
			$stmt = $DB_con->prepare('INSERT INTO  brand(brand,DID,timestamp) VALUES(:brand,:DID,:timestamp)');
			$stmt->bindParam(':brand',$txtBrand);
			$stmt->bindParam(':DID',$DID);
            $stmt->bindParam(':timestamp',$date);
			
			if($stmt->execute())
			{
                            echo '<script language="javascript">';
echo 'alert("Saved successfully")';
echo '</script>';
}
			else
			{
                            echo '<script language="javascript">';
echo 'alert("error while Save...")';
echo '</script>';
			}
		}
	}
	
}
        ?>
		
		
  
  <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
		  <form method="post" enctype="multipart/form-data">
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Enter Brand Details</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              
                <!-- text input -->
                <div class="form-group">
                  <label>Enter Brand Name</label>
                  <input type="text" id="txtBrand" name="txtBrand" class="form-control" placeholder="Enter ...">
                </div>

              
            </div>
            <!-- /.box-body -->
			<div class="box-footer">
			<input type="submit" id="save" name="save" class="btn btn-primary" value="Submit"/>
              </div>
          </div>
</form>
        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">
          
		  <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Display Brands</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody><tr>
                  <th style="width: 10px">#</th>
                  <th>Brand Name</th>
                </tr>
				
		<?php	
		$query="SELECT * FROM brand where status=0 ORDER BY BID DESC";
        $result= mysqli_query($DB, $query);
        $i=1;
	while($row= mysqli_fetch_array($result))
		{
			?>	
                <tr>
                  <td><?php echo $i ?></td>
                  <td><?php echo $row['brand']; ?></td>
				  <td><a href="UBrand.php?BID=<?php echo $row['BID']; ?>">Edit</a></td>
                </tr>
                
                <?php
				$i++;
		}
	
?>
				
              </tbody></table>
            </div>
            <!-- /.box-body 
            <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>-->
          </div>
          
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
  
  </div>
  
		
		<?php
        include 'footer.php';
        ?>