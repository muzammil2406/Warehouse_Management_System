<?php
        include 'header.php';
        ?>
		
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Create Business Man
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Create User</li>
      </ol>
    </section>
  <?php
require_once 'dbconfig.php';

        if(isset($_POST['save']))
	{
		
                $txtUname = $_POST['txtUname'];// user name
                $txtEmail = $_POST['txtEmail'];// user name
                $txtMob = $_POST['txtMob'];// user name
                $txtPass = $_POST['txtPass'];
				if($Auth=='Admin' || $Auth=='RM')
	  {
				$Manager = $_POST['Manager'];
	  }
	  else
	  {
		  $Manager =$_SESSION['UID'];
	  }
				
				
		$date = date('Y-m-d H:i:s');
                $autho = 'user';
				$DID=$_SESSION['UID'];
                if(!empty($txtUname) && !empty($txtPass))
				{
                if(!isset($errMSG))
		{
			$stmt = $DB_con->prepare('INSERT INTO  mst_user(Mgr,username,password,authority,email,mobile,DID,target,timestamp) VALUES(:Mgr,:username,:password,:authority,:email,:mobile,:DID,1000,:timestamp)');
			
			 $stmt->bindParam(':Mgr',$Manager);
                        $stmt->bindParam(':username',$txtUname);
                        $stmt->bindParam(':password',$txtPass);
						$stmt->bindParam(':authority',$autho);
                        $stmt->bindParam(':email',$txtEmail);
                        $stmt->bindParam(':mobile',$txtMob);
						//$stmt->bindParam(':target',$txtTar);
                        $stmt->bindParam(':DID',$DID);
						$stmt->bindParam(':timestamp',$date);
			
			if($stmt->execute())
			{
                            echo '<script language="javascript">';
echo 'alert("Register successfully")';
echo '</script>';

			}
			else
			{
                            echo '<script language="javascript">';
echo 'alert("error while Register...")';
echo '</script>';
			}
		}
				}
				else
				{
					echo '<script language="javascript">';
echo 'alert("Please Enter Required Fields")';
echo '</script>';
					
				}
        }
        
        ?>
        
		
		
  <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Enter Business Man Details</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
             <form method="post"  enctype="multipart/form-data">
			 
	  <div class="form-group has-feedback">
        <input type="text" name="txtUname" class="form-control" placeholder="User Name">
        <span class="glyphicon glyphicon-user form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="email" name="txtEmail" class="form-control" placeholder="Email">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
	  
	  <div class="form-group has-feedback">
        <input type="text" name="txtMob" class="form-control" placeholder="Mobile">
        <span class="glyphicon glyphicon-phone form-control-feedback"></span>
      </div>
	  <?PHP
	  $Auth=$_SESSION['Auth'];
	  if($Auth=='Admin' || $Auth=='RM')
	  {
		  ?>
	  <div class="form-group">
                  
				  <select name="Manager" class="form-control">
<option value='0'>-- Select Manager --</option>
                  <?php
		$query="SELECT * FROM mst_user where authority='Manager'";
        $result= mysqli_query($DB, $query);
	while($row= mysqli_fetch_array($result))
		{
			?>
               <option value="<?php echo $row['UID'];?>"><?php echo $row['username'];?></option>
            <?php
		}
?>
   </select>             
   </div>
	  <?PHP
	  }
	  else if($Auth=='SS')
	  {
		  ?>
	  <div class="form-group">
                  
				  <select name="Manager" class="form-control">
<option value='0'>-- Select Manager --</option>
                  <?php
				  $SS=$_SESSION['UID'];
		$query="SELECT * FROM mst_user where authority='Manager' and SS=$SS";
        $result= mysqli_query($DB, $query);
	while($row= mysqli_fetch_array($result))
		{
			?>
               <option value="<?php echo $row['UID'];?>"><?php echo $row['username'];?></option>
            <?php
		}
?>
   </select>             
   </div>
	  <?PHP
	  }
	  ?>
      <div class="form-group has-feedback">
        <input type="password" name="txtPass" class="form-control" placeholder="Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
	  
      <div class="form-group has-feedback">
        <input type="password" name="txtCPass" class="form-control" placeholder="Retype password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
        <div class="box-footer">
                <input type="submit" id="save" name="save" class="btn btn-primary" value="Submit"/>
              </div>
	  
    </form>

        </div>
        <!--/.col (left) -->
		</div>
		
		</div>
        
		
      </div>
	  
	  <div class="row">
	  
	  <div class="col-md-12">
          
		  <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Display Business Man Details</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody><tr>
                  <th style="width: 10px">#</th>
                  
                  <th>User Name</th>
                  <th>Email ID</th>
				  <th>Mobile No</th>
				  <th>Inserted By</th>
				  <th>Authority</th>
				  <th>Date</th>
                </tr>
                
				
				<?php	
				$DID=$_SESSION['UID'];	
$Auth=$_SESSION['Auth'];
	  if($Auth=='Admin' || $Auth=='RM')
	  {
		$query="SELECT MU.UID,MU.username,MU.timestamp, mst_user.username AS SS, MU.email, MU.mobile, MU.authority FROM mst_user AS MU INNER JOIN mst_user ON MU.DID = mst_user.UID WHERE (MU.authority = 'user')";
	  }
	  else
	  {
		  $query="SELECT MU.UID,MU.username,MU.timestamp, mst_user.username AS SS, MU.email, MU.mobile, MU.authority FROM mst_user AS MU INNER JOIN mst_user ON MU.DID = mst_user.UID WHERE (MU.authority = 'user') AND (MU.DID = $DID)";
	  }	
        $result= mysqli_query($DB, $query);
        $i=1;
	while($row= mysqli_fetch_array($result))
		{
			?>	
                <tr>
                  <td><?php echo $i ?></td>
                  <td><a href="ALLCust.php?UID=<?php echo $row['UID']; ?>"><?php echo $row['username']; ?></a></td>
				  <td><?php echo $row['email']; ?></td>
				  <td><?php echo $row['mobile']; ?></td>
				  <td><?php echo $row['SS']; ?></td>
				  <td><?php echo $row['authority']; ?></td>
				  <td><?php 
				  $date = date_create($row['timestamp']);
				  echo date_format($date, 'd/m/Y'); ?></td>
				  
				  <td><a href="user.php?UID=<?php echo $row['UID']; ?>">Edit</a></td>
                </tr>
        <?php
				$i++;
	}
?>				
				
              </tbody>
			  </table>
            </div>
			
          </div>
          
        </div>
        <!--/.col (right) -->
	  </div>
	  
	  
	  
      <!-- /.row -->
    </section>
  
  </div>
  
  
		
		<?php
        include 'footer.php';
        ?>