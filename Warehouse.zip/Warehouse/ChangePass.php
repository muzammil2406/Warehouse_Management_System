<?php
        include 'header.php';
        ?>
		
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Change Password
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Change Password</li>
      </ol>
    </section>
  
  
   <?php
require_once 'dbconfig.php';

        if(isset($_POST['save']))
	{
		
                $txtNPass = $_POST['txtNPass'];
                $UID=$_SESSION['UID'];
				
			$stmt = $DB_con->prepare('UPDATE mst_user SET password = :password WHERE     (UID = :UID)');
			$stmt->bindParam(':password',$txtNPass);
			$stmt->bindParam(':UID',$UID);
			if($stmt->execute())
			{
                            echo '<script language="javascript">';
echo 'alert("Password Changed successfully")';
echo '</script>';
}
			else
			{
                            echo '<script language="javascript">';
echo 'alert("error while Password Changing...")';
echo '</script>';
			}
		}
		
        
        ?>
		
  <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
	<form method="post" enctype="multipart/form-data">
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Change Password</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <div class="form-group has-feedback">
                  <label>Enter Old Password</label>
                  <input type="password" id="txtOPass" name="txtOPass" class="form-control" placeholder="Enter Old Password">
                </div>
				<div class="form-group has-feedback">
                  <label>Enter New Password</label>
                  <input type="password" id="txtNPass" name="txtOPass" class="form-control" placeholder="Enter New Password">
                </div>
				<div class="form-group has-feedback">
                  <label>Enter Confirm Password</label>
                  <input type="password" id="txtCPass" name="txtOPass" class="form-control" placeholder="Enter Confirm Password">
                </div>
            </div>
			<div class="box-footer">
	<input type="submit" id="save" name="save" class="btn btn-primary" value="Submit"/>
            </div>
          </div>
	</form>
        </div>
      </div>
    </section>
  </div>
		<?php
        include 'footer.php';
        ?>