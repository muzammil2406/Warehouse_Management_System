<?php
        include 'header.php';
        ?>
		
		<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA2_pMn6zNnwpFz8LHiF86paqYKgnE-atA&sensor=false&libraries=places"></script>
<script type="text/javascript">

    //Array of JSON objects.
    var markers = [
    {
		<?php
		if(isset($_POST['show']))
		{
  include 'dbconfig.php';
  $user = $_POST['user'];
  $findmap = "SELECT * FROM location where UID=$user";
 
  if(!$result = $DB->query($findmap)){
     die('There was an error running the query [' . $con->error . ']');
  } else {
    $row = $result->fetch_assoc();
    $lat = $row['latitude'];
    $long = $row['longitude'];
  }  
		}
?>
        "title": <?php echo $lat?>,
        "lat": <?php echo $lat?>,
        "lng": <?php echo $long?>,
        "description": <?php echo $lat?>
    }
    ];
    window.onload = function () {
        LoadMap();
    }
    function LoadMap() {
        var mapOptions = {
            center: new google.maps.LatLng(markers[0].lat, markers[0].lng),
            zoom: 0,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var infoWindow = new google.maps.InfoWindow();
        var latlngbounds = new google.maps.LatLngBounds();
        var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
 
        for (var i = 0; i < markers.length; i++) {
            var data = markers[i]
            var myLatlng = new google.maps.LatLng(data.lat, data.lng);
            var marker = new google.maps.Marker({
                position: myLatlng,
                map: map,
                title: data.title
            });
            (function (marker, data) {
                google.maps.event.addListener(marker, "click", function (e) {
                    infoWindow.setContent("<div style = 'width:200px;min-height:40px'>" + data.description + "</div>");
                    infoWindow.open(map, marker);
                });
            })(marker, data);
            latlngbounds.extend(marker.position);
        }
        var bounds = new google.maps.LatLngBounds();
        map.setCenter(latlngbounds.getCenter());
        map.fitBounds(latlngbounds);
    }
</script>
		
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Location
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Location</li>
      </ol>
    </section>
 
  <section class="content">
  <form method="post" enctype="multipart/form-data">
      <div class="row">
        <div class="col-md-6">
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">User</h3>
            </div>
            <div class="box-body">
                <div class="form-group">
                  <label>Select User Name</label>
				  <select name="user" class="form-control">
<option selected="selected">-- Select User Name --</option>
                  <?php
		$query="SELECT * FROM mst_user";
        $result= mysqli_query($DB, $query);
	while($row= mysqli_fetch_array($result))
		{
			?>
               <option value="<?php echo $row['UID'];?>"><?php echo $row['username'];?></option>
            <?php
		}
?>
   </select>             
   </div>
   
                </div>  
            </div>
            <!-- /.box-body -->
			
			<div class="box-footer">
            <input type="submit" id="show" name="show" class="btn btn-primary" value="Submit"/>
            </div>
			  
          </div>
        </div>
		
		</form>
		<div class="col-md-6">
		</div>
		
		<hr>
        <div class="row">
		<div class="col-md-12">
		  <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Display Users Location</h3>
            </div>
            <div class="box-body">
<div id="dvMap" style="width: 100%; height:300px">
			</div>
          </div>
        </div>
      </div>
	  </div>
    </section>
  </div>
		<?php
        include 'footer.php';
        ?>