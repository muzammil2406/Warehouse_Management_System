<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>DASFMCG</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="../../index2.html"><b>DASFMCG</b></a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Sign in to start your session</p>
 <?php
session_start();
session_unset();
session_destroy();
?>

<?php
        require_once 'dbconfig.php';
        if(isset($_POST['btnLog']))
	{
if (isset($_POST['email']) and isset($_POST['password']))
    {
//3.1.1 Assigning posted values to variables.
$email = $_POST['email'];
$password = $_POST['password'];
      $query="SELECT * FROM `mst_user` WHERE username='$email' and password='$password'";
        $result= mysqli_query($DB, $query);
        session_start();
	if(mysqli_num_rows($result)==1)
	{
            while($row= mysqli_fetch_array($result))
		{
                $_SESSION['email']= $row["email"];
                    $Auth=$row["authority"];
					
					$_SESSION['Auth']= $row["authority"];
                    
    $_SESSION['UID']= $row["UID"];
	$_SESSION['DID']= $row["DID"];
	$_SESSION['RM']= $row["RM"];
	$_SESSION['SS']= $row["SS"];
    echo '<script language="javascript">window.location.href= "index.php";</script>';
                    
                }
        }
 else {
    echo '<script language="javascript">';
echo 'alert("User Name or Password is Incorrect")';
echo '</script>';
}
}
else
    {
echo '<script language="javascript">';
echo 'alert("User Name or Password is Incorrect")';
echo '</script>';
}
}
?>


    <form method="post" enctype="multipart/form-data">
      <div class="form-group has-feedback">
        <input type="text" class="form-control" name="email" placeholder="User Name">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" name="password" placeholder="Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
	  <div class="col-xs-1">
	  </div>
        <div class="col-xs-6">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox"> Remember Me
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          
		  <button type="submit" name="btnLog" class="btn btn-primary btn-block btn-flat">Login</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="../../bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="../../plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>
