<?php

	//$DB_HOST = 'localhost';
	//$DB_USER = 'root';
	//$DB_PASS = '';
	//$DB_NAME = 'DasOrder';
	
	$DB_HOST = 'localhost';
	$DB_USER = 'dasordrs';
	$DB_PASS = 'dasordrs@123';
	$DB_NAME = 'dasordrs';
	
	try{
		$DB_con = new PDO("mysql:host={$DB_HOST};dbname={$DB_NAME}",$DB_USER,$DB_PASS);
		$DB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
		$DB= mysqli_connect("localhost","dasordrs","dasordrs@123","dasordrs")or die("Unable to connect");
		
		//$DB= mysqli_connect("localhost","root","","DasOrder")or die("Unable to connect");
		
		$selectDb  = mysqli_select_db($DB, $DB_NAME);
	}
	catch(PDOException $e){
		echo $e->getMessage();
	}