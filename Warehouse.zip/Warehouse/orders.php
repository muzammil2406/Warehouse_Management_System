
<?php
        include 'header.php';
        ?>

<div class="content-wrapper" style="min-height: 262.92px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Orders</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
     
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <div class="col-md-12">
          <!-- MAP & BOX PANE -->
          
          <!-- TABLE: LATEST ORDERS -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Latest Orders</h3>
</div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin">
                  <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Executive Name</th>
                  </tr>
                  </thead>
                  <tbody>
                  
				  <?php	
		$query="SELECT     mo.OID, c.custname, c.addr, c.mobile, c.email, c.gst, c.UID, mo.CID, mo.date, mo.total, mo.paid, mo.unpaid, mo.status, mu.username
FROM         mst_orde AS mo INNER JOIN
                      mst_user AS mu ON mo.UID = mu.UID INNER JOIN
                      customer AS c ON mo.CID = c.CID ORDER BY mo.OID DESC";
        $result= mysqli_query($DB, $query);
	while($row= mysqli_fetch_array($result))
		{
			?>	
			<tr>
			<td><a href="invoice.php?OID=<?php echo $row['OID']; ?>"><?php echo $row['OID']; ?></a></td>
                    <td><?php echo $row['custname']; ?></td>
					<td>
                      <div class="sparkbar" data-color="#00a65a" data-height="20"><?php echo $row['username']; ?></div>
                    </td>
					</tr>
                <?php
						}
	
?>
				  
                  
                   </tbody>
                </table>
             
				
				</div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              
              <a href="AllOrders.php" class="btn btn-sm btn-default btn-flat pull-right">View All Orders</a>
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
		
		<?php
        include 'footer.php';
        ?>