<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA2_pMn6zNnwpFz8LHiF86paqYKgnE-atA&sensor=false&libraries=places"></script>
<script type="text/javascript">
    //Array of JSON objects.
    var markers = [
    {
        "title": 'Aksa Beach',
        "lat": '16.677575',
        "lng": '74.4725286',
        "description": 'Aksa Beach is a popular beach and a vacation spot in Aksa village at Malad, Mumbai.'
    },
    {
        "title": 'Juhu Beach',
        "lat": '16.684711',
        "lng": '74.4721623',
        "description": 'Juhu Beach is one of favorite tourist attractions situated in Mumbai.'
    },
    {
        "title": 'Jijamata Udyan',
        "lat": '16.683272',
        "lng": '74.473691',
        "description": 'Jijamata Udyan is situated near Byculla station is famous as Mumbai (Bombay) Zoo.'
    }
    ];
    window.onload = function () {
        LoadMap();
    }
    function LoadMap() {
        var mapOptions = {
            center: new google.maps.LatLng(markers[0].lat, markers[0].lng),
            zoom: 2,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var infoWindow = new google.maps.InfoWindow();
        var latlngbounds = new google.maps.LatLngBounds();
        var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
 
        for (var i = 0; i < markers.length; i++) {
            var data = markers[i]
            var myLatlng = new google.maps.LatLng(data.lat, data.lng);
            var marker = new google.maps.Marker({
                position: myLatlng,
                map: map,
                title: data.title
            });
            (function (marker, data) {
                google.maps.event.addListener(marker, "click", function (e) {
                    infoWindow.setContent("<div style = 'width:200px;min-height:40px'>" + data.description + "</div>");
                    infoWindow.open(map, marker);
                });
            })(marker, data);
            latlngbounds.extend(marker.position);
        }
        var bounds = new google.maps.LatLngBounds();
        map.setCenter(latlngbounds.getCenter());
        map.fitBounds(latlngbounds);
    }
</script>
<div id="dvMap" style="width: 1000px; height:600px">
</div>