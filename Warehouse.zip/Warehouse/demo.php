<?php
 
  include 'dbconfig.php';
 
  $apikey = "AIzaSyA2_pMn6zNnwpFz8LHiF86paqYKgnE-atA";
  //$id = $_GET['id'];
 
  $lat = 0;
  $long = 0;
  $zoom = 8;
 
  $findmap = "SELECT * FROM location";
 
  if(!$result = $DB->query($findmap)){
     die('There was an error running the query [' . $con->error . ']');
  } else {
    $row = $result->fetch_assoc();
    $lat = $row['latitude'];
    $long = $row['longitude'];
    $zoom = 8;
  }   
?>

<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport"
        content="initial-scale=1.0, user-scalable=no" />
    <style type="text/css">
      html { height: 100% }
      body { height: 100%; margin: 0; padding: 0 }
      #map-canvas { height: 100% }
    </style>
    <script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?key=
          <?php echo $apikey; ?>&sensor=false">
    </script>
    <script type="text/javascript">
      function initialize() {
        var mapOptions = {
          center: new google.maps.LatLng(<?php echo $lat.', '.$long; ?>),
          zoom: <?php echo $zoom; ?>
        };
        var map = new google.maps.Map(document.getElementById("map-canvas"),
            mapOptions);
      }
      google.maps.event.addDomListener(window, 'load', initialize);
    </script>
  </head>
  <body>
    <div id="map-canvas"/>
  </body>
</html>

<?php
  $getpoints = "SELECT * FROM location";
 
  if(!$result = $DB->query($getpoints)){
    die('There was an error running the query 
        [' . $con->error . ']');
  } else {
    while ($row = $result->fetch_assoc()) {
      echo 'var myLatlng1 = new google.maps.LatLng('.
          $row['latitude'].', '.$row['longitude'].'); 
  var marker1 = new google.maps.Marker({ 
    position: '.$row['latitude'].', '.$row['longitude'].', 
    map: map, title:"'.$row['UID'].'"
  });';
    }
  }
?>