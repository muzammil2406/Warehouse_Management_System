<!DOCTYPE html>
 <?php
 session_start();
if(!$_SESSION['UID'])
{
echo '<script language="javascript">window.location.href= "login.php";</script>';
}
require_once 'dbconfig.php';
?>	
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SNS India Foods</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
<link rel="stylesheet" href="custome.css">
  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <header class="main-header">
    <!-- Logo -->
    <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>SNS</b></span>  
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>SNS India </b>Foods</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li>
            <a href="login.php">Log Out</a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="dist/img/1.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>SNS India Foods</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
       <li><a href="brand.php"><i class="fa fa-circle-o text-green"></i> <span>Add Brand</span></a></li>
        <li><a href="product.php"><i class="fa fa-circle-o text-red"></i> <span>Add Product</span></a></li>
		<li><a href="city.php"><i class="fa fa-circle-o text-green"></i> <span>Add City</span></a></li>
        <li><a href="root.php"><i class="fa fa-circle-o text-yellow"></i> <span>Add Root</span></a></li>
		<li><a href="distributor.php"><i class="fa fa-circle-o text-pink"></i> <span>Add Distributor</span></a></li>
		<li><a href="user.php"><i class="fa fa-circle-o text-pink"></i> <span>Add Salesman</span></a></li>
		 <li><a href="addcust.php"><i class="fa fa-circle-o text-blue"></i> <span>Add Outlate</span></a></li>
		<li><a href="UserRoute.php"><i class="fa fa-circle-o text-yellow"></i> <span>Salesman Root Attachment</span></a></li>
		<li><a href="CustLocation.php"><i class="fa fa-circle-o text-green"></i> <span>Location</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>