<?php
        include 'header.php';
        ?>
		
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Payment
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Payment</li>
      </ol>
    </section>
  
  
   <?php
require_once 'dbconfig.php';

        if(isset($_POST['save1']))
	{
		$save=$_POST['save'];
				
		if($save=='Submit')
		{
                $txtBrand = $_POST['txtBrand'];// user name
		$date = date('Y-m-d H:i:s');
                $DID=$_SESSION['UID'];
                if(!isset($errMSG))
		{
			$stmt = $DB_con->prepare('INSERT INTO  brand(brand,DID,timestamp) VALUES(:brand,:DID,:timestamp)');
			$stmt->bindParam(':brand',$txtBrand);
			$stmt->bindParam(':DID',$DID);
            $stmt->bindParam(':timestamp',$date);
			
			if($stmt->execute())
			{
                            echo '<script language="javascript">';
echo 'alert("Saved successfully")';
echo '</script>';
}
			else
			{
                            echo '<script language="javascript">';
echo 'alert("error while Save...")';
echo '</script>';
			}
		}
	}
	
}
        ?>
		
		
  
  <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
		  <form method="post" enctype="multipart/form-data">
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Enter Payment Details</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              
                <!-- text input -->
                <div class="form-group">
                  <label>Enter Amount</label>
                  <input type="text" id="txtBrand" name="txtBrand" class="form-control" placeholder="Enter ...">
                </div>

              
            </div>
            <!-- /.box-body -->
			<div class="box-footer">
			<input type="submit" id="save" name="save" class="btn btn-primary" value="Submit"/>
              </div>
          </div>
</form>
        </div>
        
		
      </div>
      <!-- /.row -->
    </section>
  
  </div>
  
		
		<?php
        include 'footer.php';
        ?>