<?php
        include 'header.php';
        ?>
		
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Product
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Product</li>
      </ol>
    </section>
  
  
  <?php
require_once 'dbconfig.php';

        if(isset($_POST['save']))
	{
                $txtPName = $_POST['txtPName'];// user name
                $txtRate = $_POST['txtRate'];// user name
                $txtMRP = $_POST['txtMRP'];
				$BID = $_POST['BID'];
		$date = date('Y-m-d H:i:s');
                //$BID = '1';
                $DID=$_SESSION['UID'];
                if(!isset($errMSG))
		{
			$stmt = $DB_con->prepare('INSERT INTO  product(Product,BID,DID,rate,mrp) VALUES(:Product,:BID,:DID,:rate,:mrp)');
			
                        $stmt->bindParam(':Product',$txtPName);
						$stmt->bindParam(':BID',$BID);
						$Auth=$_SESSION['Auth'];
						if($Auth=='Admin')
						{
							$DID='0';
						$stmt->bindParam(':DID',$DID);
						}
						else
						{
						$stmt->bindParam(':DID',$DID);
						}
                        $stmt->bindParam(':rate',$txtRate);
						$stmt->bindParam(':mrp',$txtMRP);
						
			if($stmt->execute())
			{
                            echo '<script language="javascript">';
echo 'alert("Saved successfully")';
echo '</script>';
			}
			else
			{
                            echo '<script language="javascript">';
echo 'alert("error while Save...")';
echo '</script>';
			}
		}
        }
        
        ?>
   
  
  <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
		
		
		<form method="post"  enctype="multipart/form-data">
          <!-- general form elements -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Enter Product Details</h3>
            </div>
            <div class="box-body">
                <div class="form-group">
                  <label>Product Name</label>
                  <input type="text" name="txtPName" class="form-control" placeholder="Enter ...">
                </div>
				<select name="BID" class="form-control">
<option selected="selected">-- Select Brand Name --</option>
                  <?php	
		$query="SELECT * FROM brand";
        $result= mysqli_query($DB, $query);
	while($row= mysqli_fetch_array($result))
		{
			?>	
               <option value="<?php echo $row['BID']; ?>"><?php echo $row['brand']; ?></option>
                
                <?php
		}
	
?>
   </select>           
				
                <div class="form-group">
                  <label>Rate</label>
                  <input type="text" name="txtRate" class="form-control" placeholder="Enter ...">
                </div>

                <div class="form-group">
                  <input type="hidden" name="txtMRP" class="form-control" placeholder="Enter ...">
                </div>
				
				
            </div>
            <!-- /.box-body -->
			<div class="box-footer">
                <input type="submit" id="save" name="save" class="btn btn-primary" value="Submit"/>
              </div>
          </div>

		  </form>
        </div>
        <!--/.col (left) -->
       <!-- right column -->
        <div class="col-md-6">
          
		  <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Display Products</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody><tr>
                  <th style="width: 10px">#</th>
                  <th>PRODUCT NAME</th>
                </tr>
				
				<?php	
		$query="SELECT P.Product, B.brand, P.rate, P.mrp FROM brand AS B INNER JOIN product AS P ON B.BID = P.BID LIMIT 6";
        $result= mysqli_query($DB, $query);
        $i=1;
	while($row= mysqli_fetch_array($result))
		{
			?>	
                <tr>
                  <td><?php echo $i ?></td>
                  <td><?php echo $row['Product']; ?></td>
                </tr>
                
        <?php
				$i++;
              
	}
	
?>		          
				
              </tbody>
			  </table>
            </div>
          </div>
        </div
      </div>
	  </div>
	   <div class="row">
	  
	  <div class="col-md-12">
          
		  <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Display Users Details</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody><tr>
                  <th style="width: 10px">#</th>
                  <th>Product Name</th>
                  <th>Brand Name</th>
                  <th>Rate</th>
                </tr>
				
				
		<?php	
		$query="SELECT P.Product, P.PID, B.brand, P.rate, P.mrp FROM brand AS B INNER JOIN product AS P ON B.BID = P.BID";
        $result= mysqli_query($DB, $query);
        $i=1;
	while($row= mysqli_fetch_array($result))
		{
			?>
                <tr>
                  <td><?php echo $i ?></td>
                  <td><?php echo $row['Product']; ?></td>
                  <td><?php echo $row['brand']; ?></td>
                  <td><?php echo $row['rate']; ?></td>
				  <td><a href="UProduct.php?PID=<?php echo $row['PID']; ?>">Edit</a></td>
                </tr>
				<?php
				$i++;
	}
	
?>		  
              </tbody>
			  </table>
            </div>
          </div>
        </div>
	  </div>
	  
    </section>
  
  </div>
  
  
		
		<?php
        include 'footer.php';
        ?>