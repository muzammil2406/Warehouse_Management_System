
<?php
        include 'header.php';
        ?>	
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ALL Manager Stock
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">ALL Manager Stock</li>
      </ol>
    </section>
 	
		
  <section class="content">
      
	  <div class="row">
	  
	  <div class="col-md-12">
          
		  <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Display Manager Stock Detail</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive">
              <table class="table table-bordered">
                <tbody><tr>
                  <th style="width: 10px">#</th>
                  
                  <th>Manager Name</th>
				  <th>Mobile No</th>
				  <th>Product</th>
				   <th>Rate</th>
				    <th>Stock</th>
					<th>Total Amount</th>
                </tr>
                
				
				<?php	
		$DID=$_SESSION['UID'];	
$Auth=$_SESSION['Auth'];
$UID=$_GET['UID'];
	  if($Auth=='Admin' || $Auth=='RM')
	  {
		$query="SELECT     mst_user.UID,mst_user.username, mst_user.mobile, stock.Stock, mst_user.authority, product.Product, product.rate, product.mrp FROM         mst_user INNER JOIN stock ON mst_user.UID = stock.TarID INNER JOIN product ON stock.PID = product.PID WHERE     (mst_user.authority = N'Manager') AND (mst_user.UID = $UID)  ORDER BY mst_user.username";
	  }
        $result= mysqli_query($DB, $query);
        $i=1;
	while($row= mysqli_fetch_array($result))
		{
			?>	
                <tr>
                  <td><?php echo $i ?></td>
                  <td><?php echo $row['username']; ?></td>
				  <td><?php echo $row['mobile']; ?></td>
				  <td><?php echo $row['Product']; ?></td>
				  <td><?php echo $row['rate']; ?></td>
				  <td><?php echo $row['Stock']; ?></td>
				  <?PHP $R=$row['rate'];
				  $S=$row['Stock'];
				  $T=$R*$S;
				  $Tot+=$T;
				  ?>
				  <td><?php echo $T; ?></td>
                </tr>
                
        <?php
				$i++;
              
	}
	
?>		    
				<tr>
				<td></td>
				<td></td><td></td><td></td><td></td><td></td>
				<td><h3><?php echo $Tot; ?></h3></td>
				</tr>
				
              </tbody>
			  </table>
            </div>
			
          </div>
          
        </div>
        <!--/.col (right) -->
	  </div>
	  
	  
	  
      <!-- /.row -->
    </section>
  
  </div>
  
  
		
		<?php
        include 'footer.php';
        ?>