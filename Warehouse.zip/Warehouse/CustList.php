
<?php
        include 'header.php';
        ?>	
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    
  <?php
require_once 'dbconfig.php';
        
        ?>
        
		
		
  <section class="content">
      
	  <div class="row">
	  
	  <div class="col-md-12">
          
		  <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Display Customers Details</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive">
              <table class="table table-bordered">
                <tbody><tr>
                  <th style="width: 10px">#</th>
                  
                  <th>Customer Name</th>
				  <th>Address</th>
				  <th>Mobile No</th>
                </tr>
				
				<?php
				$Auth=$_SESSION['Auth'];
				$UID=$_SESSION['UID'];
				if($Auth=='Admin' || $Auth=='RM')
	  {
		$query="SELECT * FROM customer";
	  }
	  else
	  {
		  $query="SELECT * FROM customer where UID=$UID";
	  }
        $result= mysqli_query($DB, $query);
        $i=1;
	while($row= mysqli_fetch_array($result))
		{
			?>	<a href="takeOrder.php?CID=<?php echo $row['CID']; ?>">
                <tr>
				
                  <td><a href="takeOrder.php?CID=<?php echo $row['CID']; ?>"><?php echo $i ?></a></td>
                  <td><a href="takeOrder.php?CID=<?php echo $row['CID']; ?>"><?php echo $row['custname']; ?></a></td>
				  <td><a href="takeOrder.php?CID=<?php echo $row['CID']; ?>"><?php echo $row['addr']; ?></a></td>
				  <td><a href="takeOrder.php?CID=<?php echo $row['CID']; ?>"><?php echo $row['mobile']; ?></a></td>
				  
                </tr></a>
                
        <?php
				$i++;
              
	}
	
?>		    
				
				
              </tbody>
			  </table>
            </div>
			
          </div>
          
        </div>
        <!--/.col (right) -->
	  </div>
	  
	  
	  
      <!-- /.row -->
    </section>
  
  </div>
  
  
		
		<?php
        include 'footer.php';
        ?>