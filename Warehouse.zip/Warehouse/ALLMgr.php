<?php
        include 'header.php';
        ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        All Managers
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">All Managers</li>
      </ol>
    </section>
  <section class="content">
	<div class="row">
	  <div class="col-md-12">
		  <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Display Users Details</h3>
            </div>
            <div class="box-body">
              <table class="table table-bordered">
                <tbody><tr>
                  <th style="width: 10px">#</th>
                  <th>User Name</th>
                  <th>Email ID</th>
				  <th>Mobile No</th>
				  <th>Inserted By</th>
				  <th>Authority</th>
				  <th>Date</th>
                </tr>
				<?php	
				$DID=$_SESSION['UID'];	
$Auth=$_SESSION['Auth'];
$UID=$_GET['UID'];
	  if($Auth=='Admin' || $Auth=='RM')
	  {
		$query="SELECT MU.UID,MU.username,MU.timestamp, mst_user.username AS SS, MU.email, MU.mobile, MU.authority FROM mst_user AS MU INNER JOIN mst_user ON MU.DID = mst_user.UID WHERE (MU.authority = 'Manager') AND (MU.DID = $UID)";
	  }
        $result= mysqli_query($DB, $query);
        $i=1;
	while($row= mysqli_fetch_array($result))
		{
			?>	
                <tr>
                  <td><?php echo $i ?></td>
                  <td><a href="ALLUsers.php?UID=<?php echo $row['UID']; ?>"><?php echo $row['username']; ?></a></td>
				  <td><?php echo $row['email']; ?></td>
				  <td><?php echo $row['mobile']; ?></td>
				  <td><?php echo $row['SS']; ?></td>
				  <td><?php echo $row['authority']; ?></td>
				   <td><?php 
				  $date = date_create($row['timestamp']);
				  echo date_format($date, 'd/m/Y'); ?></td>
                </tr>
            <?php
				$i++;
	    }
?>
              </tbody>
			  </table>
            </div>
          </div>
        </div>
	  </div>
    </section>
  </div>
		<?php
        include 'footer.php';
        ?>