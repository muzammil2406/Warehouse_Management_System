<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
<?php
	  $Auth=$_SESSION['Auth'];
	  if($Auth=='Admin')
	  {
		  ?>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-lg-12 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
			
			
			<?php	
		$query="SELECT COUNT(CID) AS CC FROM customer";
        $result= mysqli_query($DB, $query);
        $i=1;
	while($row= mysqli_fetch_array($result))
		{
			?>	
                <h3><?php echo $row['CC']; ?>+</h3>
                <?php
				$i++;
		}
	
?>
              <p>All Customers</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="addcust.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
		
		<div class="col-lg-12 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
			
			
			<?php	
		$query="SELECT COUNT(UID) AS CC FROM mst_user where authority='user'";
        $result= mysqli_query($DB, $query);
        $i=1;
	while($row= mysqli_fetch_array($result))
		{
			?>	
                <h3><?php echo $row['CC']; ?>+</h3>
                <?php
				$i++;
		}
	
?>
              <p>All Salesman</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="user.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
		
		 <div class="col-lg-12 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <?php	
		$query="SELECT sum(total) AS total FROM mst_orde where DATE(createdat) = CURDATE()";
        $result= mysqli_query($DB, $query);
        $i=1;
	while($row= mysqli_fetch_array($result))
		{
			?>	
                <h3><?php
				$tot=$row['total'];
				echo round($tot, 2); ?>+</h3>
                <?php
				$i++;
		}
	
?>
              <p>Todays Total Amount</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
      </div>

      <!-- Main row -->
      <div class="row">
        <!-- <div class="col-md-8">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Latest Orders</h3>
</div>
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin">
                  <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Executive Name</th>
                  </tr>
                  </thead>
                  <tbody>
                  
				  <?php	
		$query="SELECT     mo.OID, c.custname, c.addr, c.mobile, c.email, c.gst, c.UID, mo.CID, mo.date, mo.total, mo.paid, mo.unpaid, mo.status, mu.username
FROM         mst_orde AS mo INNER JOIN
                      mst_user AS mu ON mo.UID = mu.UID INNER JOIN
                      customer AS c ON mo.CID = c.CID ORDER BY mo.OID DESC";
        $result= mysqli_query($DB, $query);
	while($row= mysqli_fetch_array($result))
		{
			?>	
			<tr>
			<td><a href="invoice.php?OID=<?php echo $row['OID']; ?>"><?php echo $row['OID']; ?></a></td>
                    <td><?php echo $row['custname']; ?></td>
					<td>
                      <div class="sparkbar" data-color="#00a65a" data-height="20"><?php echo $row['username']; ?></div>
                    </td>
					</tr>
                <?php
						}
	
?>
				  
				  
				  
				  
                    
                  
                   </tbody>
                </table>
              </div>
         
            </div>
           
            <div class="box-footer clearfix">
              <a href="AllOrders.php" class="btn btn-sm btn-default btn-flat pull-right">View All Orders</a>
            </div>
        
          </div>
       
        </div>

        <div class="col-md-4">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">ProductS Order</h3>
            </div>
            <div class="box-body">
              <ul class="products-list product-list-in-box">
               
<?php	
		$query="SELECT     P.Product, tor.PID, SUM(tor.qty) AS qty FROM tbl_order AS tor INNER JOIN product AS P ON tor.PID = P.PID GROUP BY P.Product, tor.PID";
        $result= mysqli_query($DB, $query);
	while($row= mysqli_fetch_array($result))
		{
			?>	
			
			<li class="item">
                  <div class="product-info">
                    <a href="javascript:void(0)" class="product-title"><?php echo $row['Product']; ?>
                      <span class="label label-warning pull-right"><?php echo $row['qty']; ?></span></a>
                    <span class="product-description">
                          <?php echo $row['Product']; ?>
                        </span>
                  </div>
                </li>
			
			
                <?php
						}
	
?>

			   
               
			   
			   
			   
              </ul>
            </div>
          </div>
        </div>
      </div>
-->
    </section>
	<?PHP
	  }
	  else if($Auth=='user')
	  {
		  echo '<script language="javascript">window.location.href= "Addcust.php";</script>';
	  }
	?>
	
	
  </div>
