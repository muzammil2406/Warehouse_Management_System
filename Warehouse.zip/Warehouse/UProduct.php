<?php
        include 'header.php';
        ?>
		
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Product
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Product</li>
      </ol>
    </section>
  
  
  <?php
require_once 'dbconfig.php';

        if(isset($_POST['save']))
	{
                $txtPName = $_POST['txtPName'];// user name
                $txtRate = $_POST['txtRate'];
				$PID = $_POST['PID'];
				
                $DID=$_SESSION['UID'];
                if(!isset($errMSG))
		{
			$stmt = $DB_con->prepare('UPDATE product SET Product = :Product, rate = :rate WHERE(PID = :PID)');
			
                        $stmt->bindParam(':Product',$txtPName);
						$stmt->bindParam(':PID',$PID);
                        $stmt->bindParam(':rate',$txtRate);
						
			if($stmt->execute())
			{
                            echo '<script language="javascript">';
echo 'alert("Updated successfully")';
echo '</script>';
echo '<script language="javascript">window.location.href= "product.php";</script>';
			}
			else
			{
                            echo '<script language="javascript">';
echo 'alert("error while Save...")';
echo '</script>';
			}
		}
        }
        
        ?>
   
  
  <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
		
		
		<form method="post"  enctype="multipart/form-data">
          <!-- general form elements -->
		  
		  <?php	
		  $PID=$_GET['PID'];
		  
		$query="SELECT * FROM product where PID=$PID";
        $result= mysqli_query($DB, $query);
		
	while($row= mysqli_fetch_array($result))
		{
			?>	
		  
		  
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Enter Product Details</h3>
            </div>
            <div class="box-body">
                <div class="form-group">
                  <label>Product Name</label>
                  <input type="text" name="txtPName" class="form-control" value="<?php echo $row['Product']; ?>">
                </div>
				
				
                <div class="form-group">
                  <label>Rate</label>
                  <input type="text" name="txtRate" class="form-control" value="<?php echo $row['rate']; ?>">
				  
				  <input type="hidden" name="PID" class="form-control" value="<?php echo $row['PID']; ?>">
                </div>

				
            </div>
            <!-- /.box-body -->
			<div class="box-footer">
                <input type="submit" id="save" name="save" class="btn btn-primary" value="Update"/>
            </div>
          </div>
<?PHP
		}?>
		  </form>
        </div>
        <!--/.col (left) -->
       </div>
	   <div class="row">
	  
	  <div class="col-md-12">
          
		  <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Display Users Details</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody><tr>
                  <th style="width: 10px">#</th>
                  <th>Product Name</th>
                  <th>Brand Name</th>
                  <th>Rate</th>
                </tr>
				
				
		<?php	
		$query="SELECT P.Product, P.PID, B.brand, P.rate, P.mrp FROM brand AS B INNER JOIN product AS P ON B.BID = P.BID";
        $result= mysqli_query($DB, $query);
        $i=1;
	while($row= mysqli_fetch_array($result))
		{
			?>
                <tr>
                  <td><?php echo $i ?></td>
                  <td><?php echo $row['Product']; ?></td>
                  <td><?php echo $row['brand']; ?></td>
                  <td><?php echo $row['rate']; ?></td>
                </tr>
				<?php
				$i++;
	}
	
?>		  
              </tbody>
			  </table>
            </div>
          </div>
        </div>
	  </div>
	  
    </section>
  
  </div>
  
  
		
		<?php
        include 'footer.php';
        ?>