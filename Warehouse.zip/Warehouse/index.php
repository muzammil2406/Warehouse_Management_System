
 <?php
        include 'header.php';
        ?>
		
  <?php
        include 'main.php';
        ?>
		
		<?php
        include 'footer.php';
        ?>
  
  
  
  