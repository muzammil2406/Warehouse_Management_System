<?php
        include 'header.php';
        ?>
		
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Add Root
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Add Root</li>
      </ol>
    </section>
  
   <?php
require_once 'dbconfig.php';

        if(isset($_POST['save']))
	{
		
                $txtroute = $_POST['txtroute'];
				//$UID = $_POST['1'];// user name
		$date = date('Y-m-d H:i:s');
                
                if(!isset($errMSG))
		{
			$UID=$_SESSION['UID'];
			$stmt = $DB_con->prepare('INSERT INTO  route(route,UID,timestamp) VALUES(:route,:UID,:timestamp)');
			
			$stmt->bindParam(':route',$txtroute);
			$stmt->bindParam(':UID',$UID);
                        $stmt->bindParam(':timestamp',$date);
			
			if($stmt->execute())
			{
                            echo '<script language="javascript">';
echo 'alert("Saved successfully")';
echo '</script>';
}
			else
			{
                            echo '<script language="javascript">';
echo 'alert("error while Save...")';
echo '</script>';
			}
		}
        }
        
        ?>
	
  <section class="content">
      <div class="row">
        <!-- left column -->
		<form method="post" enctype="multipart/form-data">
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Enter Root Details</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <!-- text input -->
                <div class="form-group">
                  <label>Enter Root Name</label>
                  <input type="text" id="txtroute" name="txtroute" class="form-control" placeholder="Enter ...">
                </div>

            </div>
            <!-- /.box-body -->
			<div class="box-footer">
                <input type="submit" id="save" name="save" class="btn btn-primary" value="Submit"/>
              </div>
          </div>

        </div>
		
              </form>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">
          
		  <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Display Roots</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody><tr>
                  <th style="width: 10px">#</th>
                  <th>Roots</th>
                  
                </tr>
				
				<?php
$UID=$_SESSION['UID'];		
$Auth=$_SESSION['Auth'];
if($Auth=='Admin' || $Auth=='RM')
{
	$query="SELECT * FROM route where status=0";
}
else{	
		$query="SELECT * FROM route where status=0 and UID=$UID";
}
        $result= mysqli_query($DB, $query);
        $i=1;
	while($row= mysqli_fetch_array($result))
		{
			?>	
                <tr>
                  <td><?php echo $i ?></td>
                  <td><?php echo $row['route']; ?></td>
                </tr>
                
                <?php
				$i++;
		}
	
?>
				</tbody></table>
            </div>
          </div>
           
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
  </div>
  
		
		<?php
        include 'footer.php';
        ?>